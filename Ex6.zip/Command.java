package command03;

public interface Command {
	public void execute();
}
